import random


"""
Objectif du fichier : faire en sorte que l'utilisateur puisse jouer au jeu du pendu amélioré sur la console.
Créé le 7 décembre 2020 à 18:44 (après la date du TP car j'ai retravaillé entre temps).
Auteur: Adrien Moreira Da Silva
"""


def motrandom():
    
    """ On ouvre le fichier et on le lit avant de donner en sortie un mot random """
    
    f = open("monfichier.txt", 'r')
    mots = f.readlines()
    return random.choice(mots)

    
def Conversionmotenliste(mot):
    
    """ Cette fonction prend en entrée mot qui correspond au mot choisit au hasard et renvoie le mot sous forme d'une liste """
    
    Bonneslettres = []
    for x in mot: 
        Bonneslettres.append(x)
    Bonneslettres.pop() #On enlève le dernier élément de la liste car il correspond à '/n' (indique un passage à une nouvelle ligne)

    return Bonneslettres


def Motmystere(mot):

    """ Cette fonction prend en entrée mot qui correspond au mot choisit au hasard. Elle renvoie en sortie le le mot mystère sous forme d'une liste. """
    """ Le mot mystère est construit ainsi: Les lettres données sont la première lettre et les lettres qui lui sont égales ; le reste vaut _ """
    
    Motmystere = [mot[0]]
    
    for k in range(1,len(mot)-1):
        if mot[k] == mot[0]:
            Motmystere.append(mot[0])
        else:
            Motmystere.append('_')

    return Motmystere
    

def Rejouer(Score,Bestscore):

    """ Rejouerounon prend en entrée le Score et le meilleur score des parties jouées pour pouvoir les afficher dans un print() en sortie. """
    """ Le but de la fonction est de savoir si l'utilisateur veut rejouer ou non. """
    
    rejouer = input( 'Voulez vous rejouer ? o pour oui ; n pour non' )
    if rejouer == "o":
        Pendu(Bestscore)
    else:
        print ('Vous avez fini ce jeu avec un score de',Score,', au revoir') 



def Pendu(Bestscore = 0):

    """ Pendu() est le jeu du pendu, il prend en entrée le meilleur score de l'utilisateur qui vaut 0 et qui est actualisé durant la partie. """
    """ La fonction renvoie en sortie des print qui indiquent à l'utilisateur où il en est dans le jeu. """
     
    Score = 8 # On initialise les chances de l'utilisateur qui correspondent en fait à son score.
    Lettresutilisees = [] # On initialise la liste des lettres entrées par le joueur.  
    
    mot = motrandom() # Sur ces 3 lignes on récupère un mot random dont on se sert pour créer une liste qui contient ce mot et une liste avec le mot mystère.
    Bonneslettres = Conversionmotenliste(mot)
    Lemotmystere = Motmystere(mot)
    
    print(Lemotmystere)


    while Lemotmystere != Bonneslettres and Score > 0: # Le jeu se fini dans deux cas: Si l'utilisateur n'a plus de chance ou s'il a trouvé le mot
        
        lettre = input('Entrez une lettre')
        
        if lettre in Bonneslettres and not(lettre) in Lemotmystere: # Si la lettre entrée est une bonne lettre qui n'est pas encore affichée dans le mot mystère.
            
            for k in range(len(Bonneslettres)):
                
                if Bonneslettres[k] == lettre: 
                    Lemotmystere[k] = lettre # Alors on affiche cette lettre à tous les emplacements où elle apparait dans le mot mystère.
                    
            print(Lemotmystere)
                       
        elif lettre in Lettresutilisees: # Si la lettre a déjà été utilisé on enlève une chance au joueur.
            
            Score -= 1 
            print('Vous avez déjà proposé cette lettre ! Plus que',Score,'chances')
            print(Lemotmystere)

        elif lettre not in Bonneslettres: # Si sa lettre est une lettre qui n'apparait pas dans le mot l'utilisateur perd aussi une chance.
            
            Score -= 1
            print('Retentez ! Il vous reste',Score,'chances')                      
            print(Lemotmystere)

        Lettresutilisees.append(lettre) # On met à jour les lettres utilisées par le joueur.
              

    
    if Score == 0:
        
        print('Vous avez perdu. Votre score est donc de', 0)
                       
    elif Lemotmystere == Bonneslettres:
        
        print('Vous avez gagné avec un score de', Score) 
        
        if Score > Bestscore: # Si l'utilisateur a trouvé le mot alors on vérifie s'il a battu son record ou non. 
            Bestscore = Score
            print('Félicitations ! vous avez battu votre record !')


    Rejouer(Score,Bestscore)

     
Pendu()
