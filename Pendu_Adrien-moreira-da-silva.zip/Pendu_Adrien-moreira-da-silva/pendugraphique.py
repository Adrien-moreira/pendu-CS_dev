import random
from tkinter import Tk, Button, Label, StringVar, Canvas, PhotoImage, NW, Entry, mainloop






"""
Objectif du fichier : faire en sorte que l'utilisateur puisse jouer au jeu du pendu en version graphique. 
Créé le : 10 décembre 2020 à 08:12
Auteur: Adrien Moreira Da Silva
"""


def motrandom():
    
    """ On ouvre le fichier et on le lit avant de donner en sortie un mot random """
    
    f = open("monfichier.txt", 'r')
    mots = f.readlines()
    return random.choice(mots)

    
def Conversionmotenliste(mot):
    
    """ Cette fonction prend en entrée mot qui correspond au mot choisit au hasard et renvoie le mot sous forme d'une liste """
    
    Bonneslettres = []
    for x in mot: 
        Bonneslettres.append(x)
    Bonneslettres.pop() #On enlève le dernier élément de la liste car il correspond à '/n' (indique un passage à une nouvelle ligne)

    return Bonneslettres


def Motmystere(mot):

    """ Cette fonction prend en entrée mot qui correspond au mot choisit au hasard. Elle renvoie en sortie le le mot mystère sous forme d'une liste. """
    """ Le mot mystère est construit ainsi: Les lettres données sont la première lettre et les lettres qui lui sont égales ; le reste vaut _ """
    
    Motmystere = [mot[0]]
    
    for k in range(1,len(mot)-1):
        if mot[k] == mot[0]:
            Motmystere.append(mot[0])
        else:
            Motmystere.append('_')

    return Motmystere
    


def Affichagedupendu():

    """Cette fonction sert à actualiser l'image du pendu. En variable global on se sert de img qui correspond à l'image initiale du pendu."""

    global img
    
    if Score == 7 or Score == 8:
        img = PhotoImage(file = "bonhomme1.gif")
    elif Score == 6:
        img = PhotoImage(file = "bonhomme2.gif")
    elif Score == 5:
        img = PhotoImage(file = "bonhomme3.gif")
    elif Score == 4:
        img = PhotoImage(file = "bonhomme4.gif")
    elif Score == 3:
        img = PhotoImage(file = "bonhomme5.gif")
    elif Score == 2:
        img = PhotoImage(file = "bonhomme6.gif")
    elif Score == 1:
        img = PhotoImage(file = "bonhomme7.gif")
    elif Score == 0:
        img = PhotoImage(file = "bonhomme8.gif")


    Canevas.create_image(60,60, anchor = NW, image = img)


def Rejouer():

    """ La fonction Rejouer se lance pour faire jouer l'utilisateur dés qu'il fait une proposition. Elle réactualise les variables quand le joueur est en fin de partie. """
    """ Cette fonction récupère en variable globale plusieurs variables (comme le mot mystère) initialisées en dehors de toute fonction. """

    global Lemotmystere,Bonneslettres,Lettresutilisees,lettre,motmystere,Infoutilisateur,Aide,Score,mot,Bestscore,random,compteur

    Submit(Lemotmystere,Bonneslettres,Lettresutilisees,lettre,motmystere,Infoutilisateur)

    
    if Score == 0:
        
        Infoutilisateur.set("Le mot était " + str(mot) + ". Vous avez perdu, votre score est de 0.") 
        Aide.set('Voici le nouveau mot, proposer une lettre pour relancer le jeu ou appuyer sur Quitter')

        # On réinitialise les données pour l'utilisateur au cas où il veut rejouer.
        
        Score = 8 
        compteur = 0 
        Lettresutilisees = []
        mot = motrandom()
        Bonneslettres = Conversionmotenliste(mot)
        Lemotmystere = Motmystere(mot)
        motmystere.set(Lemotmystere) 


        
    elif Lemotmystere == Bonneslettres:
        
        Infoutilisateur.set("Le mot était bien " + str(mot) + '. Vous avez gagné avec un score de ' + str(Score)) 
        Aide.set('Voici le nouveau mot, Proposer une lettre pour relancer le jeu ou appuyer sur Quitter')

    
        Bestscoreliste.append(Score)
        Bestscoreliste.sort()
        Meilleurescores.set(" Vos 3 meilleurs scores : " + str(Bestscoreliste[-3:])) # On trie la liste des meilleures des parties jouées pour pouvoir afficher les 3 meilleurs scores plus facilement.


        if Score > Bestscore: # Si l'utilisateur a trouvé le mot alors on vérifie s'il a battu son record ou non. 
            Bestscore = Score
            Infoutilisateur.set("Le mot était bien " + str(mot) + 'Vous avez battu votre nouveau record ! Il est maintenant de ' + str(Bestscore))

        # On réinitialise les données pour l'utilisateur au cas où il veut rejouer.
        
        Score = 8
        compteur = 0 
        Lettresutilisees = []           
        mot = motrandom()
        Bonneslettres = Conversionmotenliste(mot)
        Lemotmystere = Motmystere(mot)
        motmystere.set(Lemotmystere) 

    
    
def Submit(Lemotmystere,Bonneslettres,Lettresutilisees,lettre,motmystere,Infoutilisateur):

    """ Voici le coeur du programme qui se déclenche une fois que le joueur appuie sur le bouton Proposer. Plusieurs variables (comme le mot mystère, les bonnes lettres du mot final etc...) sont en arguments car elles proviennent de la fonction Rejouer(). """
    """ En sortie on informe le joueur en fonction de ce qu'il a proposé et on adapte le programme. """
    
    Bestscore = 0 

    global Score, Canevas, img, random, compteur, Alphabet # On récupère en variable globale les variables initialisées hors de toute fonction.

    Infoutilisateur.set('')
    Aide.set('')

 
    
    if Lemotmystere != Bonneslettres and Score > 0 and lettre.get() in Alphabet : # Le jeu se fini dans deux cas: Si l'utilisateur n'a plus de chance ou s'il a trouvé le mot

        if lettre.get() in Bonneslettres and not(lettre.get()) in Lemotmystere: # Si la lettre entrée est une bonne lettre qui n'est pas encore affichée dans le mot mystère.               
            for k in range(len(Bonneslettres)):                   
                if Bonneslettres[k] == lettre.get():
                    Lemotmystere[k] = lettre.get() # Alors on affiche cette lettre à tous les emplacements où elle apparait dans le mot mystère.

        
            motmystere.set(Lemotmystere)

        if lettre.get() in Lettresutilisees: # Si la lettre a déjà été utilisé on enlève une chance au joueur.
                
            Score -= 1
            Infoutilisateur.set('Vous avez déjà proposé cette lettre ! Plus que ' + str(Score) + ' chance(s)') # On affiche le mot mystère



        elif lettre.get() not in Bonneslettres: # Si sa lettre est une lettre qui n'apparait pas dans le mot l'utilisateur perd aussi une chance.
                
            Score -= 1
            Infoutilisateur.set('Il vous reste ' + str(Score) + ' chance(s)') # On affiche le mot mystère


        Lettresutilisees.append(lettre.get()) # On met à jour les lettres utilisées par le joueur.
        

    elif lettre.get() not in Alphabet: # Le joueur doit rentrer une lettre de l'alphabet s'il veut que le jeu fonctionne ! 
        
        Infoutilisateur.set("Ceci n'est pas une lettre !")




    Affichagedupendu()



    # On aide l'utilisateur quand il ne lui reste que 4 chances. Le compteur fait en sorte qu'on ne l'aide qu'une seule fois.
    # On met dans une liste les lettres manquantes du mot mystère et on choisit une lettre au hasard que l'on propose par la suite à l'utilisateur.
    
    if Score == 4:

        compteur += 1
        Lettresmanquantes = []

        for x in Bonneslettres: 
            if x not in Lemotmystere:
                Lettresmanquantes.append(x) 
        
        if compteur == 1 and len(Lettresmanquantes) > 0: 
            Aide.set('Une petite aide ne vous fera pas de mal ! Pour vous débloquer, proposez la lettre ' + str(random.choice(Lettresmanquantes)))
                                        






Lettresutilisees = [] # On initialise la liste des lettres entrées par le joueur.  
    
mot = motrandom() # Sur ces 3 lignes on récupère un mot random dont on se sert pour créer une liste qui contient ce mot et une liste avec le mot mystère.
Bonneslettres = Conversionmotenliste(mot)
Lemotmystere = Motmystere(mot)



# Initialisation des variables et de l'affichage graphique

Score = 8 
compteur = 0
Bestscoreliste = []
Bestscore = 0
Alphabet = ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
Mafenetre = Tk()
Mafenetre.title('Jeu du pendu')
Canevas = Canvas(Mafenetre, width = 550, height = 400)
img = PhotoImage(file = "bonhomme1.gif")
Canevas.create_image(60, 60, anchor = NW, image = img)
Canevas.grid(row = 2, column = 0 )

# On place toutes les variables avec grid.
# Initialisation du mot mystère et affichage de celui-ci.

motmystere = StringVar()
label = Label( Mafenetre, textvariable=motmystere, foreground = 'blue', font = 'Times 25')
label.grid(row = 2,column = 1)
motmystere.set(Lemotmystere) 

# Initialisation des informations qu'on va dire à l'utilisateur.

Infoutilisateur = StringVar()
Infos = Label( Mafenetre, textvariable = Infoutilisateur)
Infos.grid(row=3)

# Initialisation de l'aide qu'on va soumettre à l'utilisateur.

Aide = StringVar()
Aideutilisateur = Label( Mafenetre, textvariable = Aide)
Aideutilisateur.grid(row = 4)

# Initialisation des Meilleurs scores des parties du joueur.

Meilleurescores = StringVar()
Meilleuresparties= Label( Mafenetre, textvariable = Meilleurescores)
Meilleuresparties.grid(row = 5)

# Initialisation d'une marge qui sert simplement à règler l'affichage Tkinter.

Margegraphique = StringVar()
Marge = Label(Mafenetre, textvariable = Margegraphique)
Marge.grid(row = 5,column = 2)
Margegraphique.set("                               ")

# Initialisation des lettres proposées par le joueur.

lettre = StringVar()
entry= Entry(Mafenetre, textvariable=lettre)
entry.grid(row = 6)

# Création du bouton Proposer.
    
submit = Button(Mafenetre, text="Proposer", command=Rejouer)
submit.grid(row = 7)

# Création du bouton quitter.

BoutonQuitter = Button(Mafenetre,text='Quitter',command=Mafenetre.destroy)
BoutonQuitter.grid(row = 8)

      
mainloop()





































